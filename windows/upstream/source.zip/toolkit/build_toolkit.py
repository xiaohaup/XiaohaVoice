"""Build a relocatable macOS arm64 toolkit. Personal data is migrated separately."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,json,os,plistlib,re,shutil,subprocess,sys
BASE=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--runtime-only',action='store_true');parser.add_argument('--skip-runtime',action='store_true');a=parser.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    work=BASE/'toolkit/build';work.mkdir(exist_ok=True)
    runtime=out/'Runtime'
    command=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onedir','--name','xiaoha-runtime','--distpath',str(runtime),'--workpath',str(work/'pyinstaller'),'--specpath',str(work),'--paths',str(BASE/'sync-suite'),'--paths',str(BASE/'ime-channel-test'),
      '--collect-submodules','desktop','--collect-submodules','server','--collect-submodules','keyring.backends','--collect-submodules','uvicorn','--collect-submodules','python_socks','--collect-data','jieba','--collect-data','certifi','--copy-metadata','keyring',str(BASE/'toolkit/runtime.py')]
    if not a.skip_runtime:
        with (work/'freeze.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    if a.runtime_only:return
    app=BASE/'mac-prototype/builds/0.3.8/小哈语音.app'
    shutil.copytree(app,out/'小哈语音.app',dirs_exist_ok=True)
    # Repacking from an existing native build must still include the current logo.
    iconset=work/'CurrentVoice.iconset'
    subprocess.run(['/usr/bin/swift','-module-cache-path',str(BASE/'diagnostics/module-cache'),str(BASE/'mac-prototype/Icon.swift'),str(iconset)],check=True)
    subprocess.run(['/usr/bin/iconutil','-c','icns',str(iconset),'-o',str(out/'小哈语音.app/Contents/Resources/XiaohaVoice.icns')],check=True)
    subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(out/'小哈语音.app')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(out/'小哈语音.app')],check=True)
    engine=out/'Components/engine';engine.mkdir(parents=True,exist_ok=True)
    for name in ['channel_probe.py','personalization.py','volcengine_asr.py','UPSTREAM-LICENSE-MIT.txt']:
        shutil.copy2(BASE/'ime-channel-test'/name,engine/name)
    source=(BASE/'ime-protocol-review/koe/source/koe-asr/src/doubaoime.rs').read_text()
    names=('WEBSOCKET_URL','REGISTER_URL','ASR_APP_KEY','APP_VERSION_CODE','APP_VERSION_NAME','USER_AGENT')
    constants={n:re.search(r'const '+n+r': &str = "([^"\n]+)";',source).group(1) for n in names}
    (engine/'protocol-constants.json').write_text(json.dumps(constants))
    opus=engine/'libopus.0.dylib'
    if opus.exists():opus.chmod(0o755)
    shutil.copy2('/opt/homebrew/opt/opus/lib/libopus.0.dylib',opus)
    subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(engine/'libopus.0.dylib')],check=True,capture_output=True)
    web=out/'Components/workbench'
    for folder in ['web','desktop','server']:
        shutil.copytree(BASE/'sync-suite'/folder,web/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','private','personal-fixtures'))
    data=out/'Data';data.mkdir(exist_ok=True,mode=0o700);(data/'.keep').touch()
    licenses=out/'LICENSES';licenses.mkdir(exist_ok=True)
    shutil.copy2(engine/'UPSTREAM-LICENSE-MIT.txt',licenses/'koe-MIT.txt')
    candidates=[Path('/opt/homebrew/opt/opus/COPYING'),Path('/opt/homebrew/opt/opus/share/doc/opus/COPYING'),Path('/opt/homebrew/opt/opus/share/opus/COPYING')]
    for p in candidates:
        if p.exists():shutil.copy2(p,licenses/'opus-COPYING.txt');break
    for dist in importlib.metadata.distributions():
        name=dist.metadata['Name']
        for file in dist.files or []:
            if ('license' in str(file).lower() or 'copying' in str(file).lower()) and '.dist-info/' in str(file) and dist.locate_file(file).is_file():
                target=licenses/name/str(file).split('.dist-info/',1)[1];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dist.locate_file(file),target)
    for candidate in [Path(sys.base_prefix)/'Resources/English.lproj/License.rtf',Path(sys.base_prefix)/'LICENSE.txt']:
        if candidate.exists():shutil.copy2(candidate,licenses/('Python-'+candidate.name))
    docs=out/'使用说明.md';docs.write_text('''# 小哈语音工具包

双击“小哈语音.app”打开，整个文件夹可一起移动。程序、运行组件和Data目录共同组成工具，不要只复制App。

- Data保存完成文字、统计原始字段、词库、草稿、设置、待恢复录音和本机识别身份。
- 应用设置可创建完整ZIP备份、校验并恢复；正常结束录音后操作。解压完整备份得到同一工具文件夹，也可先打开本程序再从备份恢复。
- 恢复会合并历史、按编号去重，保留当前新记录；冲突原件另存Data/restore-preserved，恢复前整个Data也有保留副本。已有设置优先，完整原件仍保留。
- API凭证和账号令牌留在操作系统安全存储中，不导出进ZIP。换Mac需重新授权麦克风、输入监控、自动粘贴；API凭证和同步账号需要重新输入或登录。
- 个人备份含私有历史、词库和识别身份，只给自己恢复；给别人使用应选择不含Data的干净程序包，在对方设备首次初始化独立身份。
- 输入法通道使用兼容协议，不需要匹配本机官方输入法程序或网页账号；新设备需明确点击首次初始化。初始化不等于识别实测，不保证每台设备都成功；遇到认证拒绝停止，不自动更换身份。正式API可手动配置。
- 录音按同一启停键开始/结束，Esc取消；可在语音输入设置中登记鼠标侧键。普通电脑操作不结束录音。
- 剪贴板可选自动粘贴或只复制；默认保留本次转写，可关闭以恢复旧剪贴板。
- 网络代理只作用于本工具。日志只记录运行元数据，不保存口述全文、音频或凭证。
- 悬浮窗保留原生界面，配色目录位于Components/workbench/web/capsule-palettes.json，颜色调整可运行时读取，无需仅为配色重编译；设置可选跟随主题、三种浅色、三种深色或初始深色。
- 当前为macOS arm64版本，Windows开发和现有电脑部署待用户确认Mac体验后继续。本备份格式与数据模型为后续迁移保留，不冒称Mac程序可在Windows运行。
''')
    manifest={'format':1,'name':'小哈语音','version':'0.3.8','platform':'macOS-arm64','data':'Data','runtime':'Runtime/xiaoha-runtime/xiaoha-runtime','cloud_deployed':False}
    (out/'toolkit.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    src=out/'维护源码';src.mkdir(exist_ok=True)
    for name in ['RuntimePaths.swift','EventLog.swift','Toolkit.swift','Gesture.swift','Hotkey.swift','AudioRecorder.swift','History.swift','Paste.swift','Session.swift','Recovery.swift','CapsuleTheme.swift','Capsule.swift','Bridge.swift','WindowChrome.swift','Desktop.swift','main.swift','Icon.swift','build.py','make-launch-alias.swift','set-file-icon.swift']:
        shutil.copy2(BASE/'mac-prototype'/name,src/name)
    shutil.copy2(BASE/'toolkit/runtime.py',src/'runtime.py')
    # No program launch, microphone use, registration or private-data copy.
    print(json.dumps({'built':True,'version':'0.3.8','data_copied':False,'runtime_bundled':True,'root':str(out)},ensure_ascii=False))

if __name__=='__main__':main()
